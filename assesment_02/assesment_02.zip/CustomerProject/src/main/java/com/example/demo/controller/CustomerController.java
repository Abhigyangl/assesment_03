package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.dao.CustomerRepo;
import com.example.demo.model.Customer;

@Controller
public class CustomerController 
{
	@Autowired
	CustomerRepo repo;
	
	@RequestMapping("/home")
	public String home()
	{
		return "home.jsp";
	}
	
	@RequestMapping(path="/customer",consumes= {"application/json"})
	public Customer addCustomer(Customer c)
	{
		repo.save(c);
		return c;
	}
	
	@GetMapping(path="/customers")
	public List<Customer> getCustomers()
	{
		return (List<Customer>) repo.findAll();
	}

	@RequestMapping("/customer/{Id}")
	public Optional<Customer> getAlien(@PathVariable("Id") int id)
	{
		return repo.findById(id);
	}
	
	@DeleteMapping("/customer/{Id}")
	public String deleteCustomer(@PathVariable int Id)
	{
		Customer c =repo.getOne(Id);
		repo.delete(c);
	    return "deleted";
	}
	

}
