package com.example.demo.controller;

import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;

@Controller

public class HelloController {

 @RequestMapping("/hello")

 public String sayHello(@RequestParam("CustId") String custid,@RequestParam("uname") String name,@RequestParam("ph") String ph,@RequestParam("ad") String ad,@RequestParam("login") String login,@RequestParam("ps") String ps,Model m)

 {

 m.addAttribute("CustId",custid);
 m.addAttribute("uname", name);
 m.addAttribute("ph",ph);
 m.addAttribute("ad", ad);
 m.addAttribute("login",login);
 m.addAttribute("ps",ps);


 return "hello";

 }

 @RequestMapping("/xx")

 public String xx()

 {
	
 return "xy";

 }

}